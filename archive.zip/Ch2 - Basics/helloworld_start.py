#
# Example file for HelloWorld
# LinkedIn Learning Python course by Joe Marini
#

def main():

    print("Hola gallo...")
    name = input("¿Cómo te llamas?")
    print("Encantado ", name)

if __name__ == "__main__":
    main()